
export const quizBank=[
 {id:'q1',prompt:'A doji usually means...',choices:['Strong uptrend','Indecision','Guaranteed reversal','High volume'],correct:1},
 {id:'q2',prompt:'Support is best described as...',choices:['Guaranteed bottom','Likely bounce zone','Moving average','Indicator'],correct:1},
 {id:'q3',prompt:'Futures are...',choices:['Rights','Obligations','Lotteries','Dividends'],correct:1},
 {id:'q4',prompt:'Best beginner risk rule?',choices:['Risk 5–10% per trade','About 1% or less','Size by feeling','No stop needed'],correct:1},
 {id:'q5',prompt:'Breakouts are stronger when...',choices:['Volume is high','Volume is zero','Price is random','It’s midnight'],correct:0},
 {id:'q6',prompt:'A hammer suggests...',choices:['Rejection of lower prices','Uptrend exhausted','Sideways trend','Nothing'],correct:0},
 {id:'q7',prompt:'RSI high often indicates...',choices:['Oversold','Overbought','No idea','Always bearish'],correct:1},
 {id:'q8',prompt:'Calls give you the right to...',choices:['Buy','Sell','Do nothing','Collect dividends'],correct:0},
 {id:'q9',prompt:'Puts give you the right to...',choices:['Buy','Sell','Print money','Get hired'],correct:1},
 {id:'q10',prompt:'Good stop placement idea...',choices:['Random','Beyond structure/level','At entry','At target'],correct:1},
]
