
export const flashcards=[
 {front:'Doji',back:'Tie game. Possible turning point.'},
 {front:'Hammer',back:'Buyers rejected lower prices (possible bounce).'},
 {front:'Shooting Star',back:'Sellers rejected higher prices (possible drop).'},
 {front:'Engulfing',back:'Big shift: one candle eats the previous.'},
 {front:'Support',back:'Floor where price often bounces.'},
 {front:'Resistance',back:'Ceiling where price often stalls.'},
 {front:'Breakout',back:'Strong close beyond a key level.'},
 {front:'Stop Loss',back:'Exit if wrong to limit damage.'},
 {front:'R:R',back:'Reward vs Risk. Aim > 1.'},
]
